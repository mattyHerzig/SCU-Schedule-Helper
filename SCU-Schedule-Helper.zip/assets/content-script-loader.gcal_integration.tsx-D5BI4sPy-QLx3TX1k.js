(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/gcal_integration.tsx-D5BI4sPy.js")
    );
  })().catch(console.error);

})();
