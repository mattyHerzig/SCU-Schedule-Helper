(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/current_courses.tsx-D8L57tQW.js")
    );
  })().catch(console.error);

})();
