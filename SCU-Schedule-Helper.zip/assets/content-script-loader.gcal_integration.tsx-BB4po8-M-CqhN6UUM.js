(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/gcal_integration.tsx-BB4po8-M.js")
    );
  })().catch(console.error);

})();
