(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/current_courses.tsx-CE32LjsQ.js")
    );
  })().catch(console.error);

})();
