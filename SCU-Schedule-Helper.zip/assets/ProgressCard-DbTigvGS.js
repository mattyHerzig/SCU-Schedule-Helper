import{r as b,d as P,b as $,s as m,m as y,f as R,D as z,j as o,a as j,o as A,h as w,E as O,n as N,G as S,e as c,p as g,H as D,I as T,B as M,w as k}from"./utils-s11dcyws.js";const E=b.createContext(),K=()=>b.useContext(E)??!1;function W(e){return $("MuiPaper",e)}P("MuiPaper",["root","rounded","outlined","elevation","elevation0","elevation1","elevation2","elevation3","elevation4","elevation5","elevation6","elevation7","elevation8","elevation9","elevation10","elevation11","elevation12","elevation13","elevation14","elevation15","elevation16","elevation17","elevation18","elevation19","elevation20","elevation21","elevation22","elevation23","elevation24"]);const G=e=>{const{square:r,elevation:t,variant:a,classes:n}=e,l={root:["root",a,!r&&"rounded",a==="elevation"&&`elevation${t}`]};return w(l,W,n)},V=m("div",{name:"MuiPaper",slot:"Root",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.root,r[t.variant],!t.square&&r.rounded,t.variant==="elevation"&&r[`elevation${t.elevation}`]]}})(y(({theme:e})=>({backgroundColor:(e.vars||e).palette.background.paper,color:(e.vars||e).palette.text.primary,transition:e.transitions.create("box-shadow"),variants:[{props:({ownerState:r})=>!r.square,style:{borderRadius:e.shape.borderRadius}},{props:{variant:"outlined"},style:{border:`1px solid ${(e.vars||e).palette.divider}`}},{props:{variant:"elevation"},style:{boxShadow:"var(--Paper-shadow)",backgroundImage:"var(--Paper-overlay)"}}]}))),X=b.forwardRef(function(r,t){var f;const a=R({props:r,name:"MuiPaper"}),n=z(),{className:l,component:d="div",elevation:i=1,square:s=!1,variant:C="elevation",...u}=a,p={...a,component:d,elevation:i,square:s,variant:C},h=G(p);return o.jsx(V,{as:d,ownerState:p,className:j(h.root,l),ref:t,...u,style:{...C==="elevation"&&{"--Paper-shadow":(n.vars||n).shadows[i],...n.vars&&{"--Paper-overlay":(f=n.vars.overlays)==null?void 0:f[i]},...!n.vars&&n.palette.mode==="dark"&&{"--Paper-overlay":`linear-gradient(${A("#fff",O(i))}, ${A("#fff",O(i))})`}},...u.style}})});function F(e){return $("MuiCard",e)}P("MuiCard",["root"]);const H=e=>{const{classes:r}=e;return w({root:["root"]},F,r)},_=m(X,{name:"MuiCard",slot:"Root",overridesResolver:(e,r)=>r.root})({overflow:"hidden"}),J=b.forwardRef(function(r,t){const a=R({props:r,name:"MuiCard"}),{className:n,raised:l=!1,...d}=a,i={...a,raised:l},s=H(i);return o.jsx(_,{className:j(s.root,n),elevation:l?8:void 0,ref:t,ownerState:i,...d})});function Q(e){return $("MuiCardContent",e)}P("MuiCardContent",["root"]);const Y=e=>{const{classes:r}=e;return w({root:["root"]},Q,r)},Z=m("div",{name:"MuiCardContent",slot:"Root",overridesResolver:(e,r)=>r.root})({padding:16,"&:last-child":{paddingBottom:24}}),rr=b.forwardRef(function(r,t){const a=R({props:r,name:"MuiCardContent"}),{className:n,component:l="div",...d}=a,i={...a,component:l},s=Y(i);return o.jsx(Z,{as:l,className:j(s.root,n),ownerState:i,ref:t,...d})});function er(e){return $("MuiLinearProgress",e)}P("MuiLinearProgress",["root","colorPrimary","colorSecondary","determinate","indeterminate","buffer","query","dashed","dashedColorPrimary","dashedColorSecondary","bar","barColorPrimary","barColorSecondary","bar1Indeterminate","bar1Determinate","bar1Buffer","bar2Indeterminate","bar2Buffer"]);const B=4,L=N`
  0% {
    left: -35%;
    right: 100%;
  }

  60% {
    left: 100%;
    right: -90%;
  }

  100% {
    left: 100%;
    right: -90%;
  }
`,tr=typeof L!="string"?S`
        animation: ${L} 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite;
      `:null,I=N`
  0% {
    left: -200%;
    right: 100%;
  }

  60% {
    left: 107%;
    right: -8%;
  }

  100% {
    left: 107%;
    right: -8%;
  }
`,ar=typeof I!="string"?S`
        animation: ${I} 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) 1.15s infinite;
      `:null,q=N`
  0% {
    opacity: 1;
    background-position: 0 -23px;
  }

  60% {
    opacity: 0;
    background-position: 0 -23px;
  }

  100% {
    opacity: 1;
    background-position: -200px -23px;
  }
`,or=typeof q!="string"?S`
        animation: ${q} 3s infinite linear;
      `:null,nr=e=>{const{classes:r,variant:t,color:a}=e,n={root:["root",`color${c(a)}`,t],dashed:["dashed",`dashedColor${c(a)}`],bar1:["bar",`barColor${c(a)}`,(t==="indeterminate"||t==="query")&&"bar1Indeterminate",t==="determinate"&&"bar1Determinate",t==="buffer"&&"bar1Buffer"],bar2:["bar",t!=="buffer"&&`barColor${c(a)}`,t==="buffer"&&`color${c(a)}`,(t==="indeterminate"||t==="query")&&"bar2Indeterminate",t==="buffer"&&"bar2Buffer"]};return w(n,er,r)},U=(e,r)=>e.vars?e.vars.palette.LinearProgress[`${r}Bg`]:e.palette.mode==="light"?D(e.palette[r].main,.62):T(e.palette[r].main,.5),ir=m("span",{name:"MuiLinearProgress",slot:"Root",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.root,r[`color${c(t.color)}`],r[t.variant]]}})(y(({theme:e})=>({position:"relative",overflow:"hidden",display:"block",height:4,zIndex:0,"@media print":{colorAdjust:"exact"},variants:[...Object.entries(e.palette).filter(g()).map(([r])=>({props:{color:r},style:{backgroundColor:U(e,r)}})),{props:({ownerState:r})=>r.color==="inherit"&&r.variant!=="buffer",style:{"&::before":{content:'""',position:"absolute",left:0,top:0,right:0,bottom:0,backgroundColor:"currentColor",opacity:.3}}},{props:{variant:"buffer"},style:{backgroundColor:"transparent"}},{props:{variant:"query"},style:{transform:"rotate(180deg)"}}]}))),sr=m("span",{name:"MuiLinearProgress",slot:"Dashed",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.dashed,r[`dashedColor${c(t.color)}`]]}})(y(({theme:e})=>({position:"absolute",marginTop:0,height:"100%",width:"100%",backgroundSize:"10px 10px",backgroundPosition:"0 -23px",variants:[{props:{color:"inherit"},style:{opacity:.3,backgroundImage:"radial-gradient(currentColor 0%, currentColor 16%, transparent 42%)"}},...Object.entries(e.palette).filter(g()).map(([r])=>{const t=U(e,r);return{props:{color:r},style:{backgroundImage:`radial-gradient(${t} 0%, ${t} 16%, transparent 42%)`}}})]})),or||{animation:`${q} 3s infinite linear`}),lr=m("span",{name:"MuiLinearProgress",slot:"Bar1",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.bar,r[`barColor${c(t.color)}`],(t.variant==="indeterminate"||t.variant==="query")&&r.bar1Indeterminate,t.variant==="determinate"&&r.bar1Determinate,t.variant==="buffer"&&r.bar1Buffer]}})(y(({theme:e})=>({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left",variants:[{props:{color:"inherit"},style:{backgroundColor:"currentColor"}},...Object.entries(e.palette).filter(g()).map(([r])=>({props:{color:r},style:{backgroundColor:(e.vars||e).palette[r].main}})),{props:{variant:"determinate"},style:{transition:`transform .${B}s linear`}},{props:{variant:"buffer"},style:{zIndex:1,transition:`transform .${B}s linear`}},{props:({ownerState:r})=>r.variant==="indeterminate"||r.variant==="query",style:{width:"auto"}},{props:({ownerState:r})=>r.variant==="indeterminate"||r.variant==="query",style:tr||{animation:`${L} 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite`}}]}))),dr=m("span",{name:"MuiLinearProgress",slot:"Bar2",overridesResolver:(e,r)=>{const{ownerState:t}=e;return[r.bar,r[`barColor${c(t.color)}`],(t.variant==="indeterminate"||t.variant==="query")&&r.bar2Indeterminate,t.variant==="buffer"&&r.bar2Buffer]}})(y(({theme:e})=>({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left",variants:[...Object.entries(e.palette).filter(g()).map(([r])=>({props:{color:r},style:{"--LinearProgressBar2-barColor":(e.vars||e).palette[r].main}})),{props:({ownerState:r})=>r.variant!=="buffer"&&r.color!=="inherit",style:{backgroundColor:"var(--LinearProgressBar2-barColor, currentColor)"}},{props:({ownerState:r})=>r.variant!=="buffer"&&r.color==="inherit",style:{backgroundColor:"currentColor"}},{props:{color:"inherit"},style:{opacity:.3}},...Object.entries(e.palette).filter(g()).map(([r])=>({props:{color:r,variant:"buffer"},style:{backgroundColor:U(e,r),transition:`transform .${B}s linear`}})),{props:({ownerState:r})=>r.variant==="indeterminate"||r.variant==="query",style:{width:"auto"}},{props:({ownerState:r})=>r.variant==="indeterminate"||r.variant==="query",style:ar||{animation:`${I} 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) 1.15s infinite`}}]}))),cr=b.forwardRef(function(r,t){const a=R({props:r,name:"MuiLinearProgress"}),{className:n,color:l="primary",value:d,valueBuffer:i,variant:s="indeterminate",...C}=a,u={...a,color:l,variant:s},p=nr(u),h=K(),f={},x={bar1:{},bar2:{}};if((s==="determinate"||s==="buffer")&&d!==void 0){f["aria-valuenow"]=Math.round(d),f["aria-valuemin"]=0,f["aria-valuemax"]=100;let v=d-100;h&&(v=-v),x.bar1.transform=`translateX(${v}%)`}if(s==="buffer"&&i!==void 0){let v=(i||0)-100;h&&(v=-v),x.bar2.transform=`translateX(${v}%)`}return o.jsxs(ir,{className:j(p.root,n),ownerState:u,role:"progressbar",...f,ref:t,...C,children:[s==="buffer"?o.jsx(sr,{className:p.dashed,ownerState:u}):null,o.jsx(lr,{className:p.bar1,ownerState:u,style:x.bar1}),s==="determinate"?null:o.jsx(dr,{className:p.bar2,ownerState:u,style:x.bar2})]})});function ur({numerator:e,denominator:r}){return o.jsx(M,{sx:{width:"100%",padding:0},children:o.jsx(cr,{sx:{padding:0},variant:"determinate",value:r===0?0:e/r*100})})}function fr({title:e,progressMessage:r,progressNumerator:t,progressDenominator:a}){return o.jsxs(J,{variant:"outlined",sx:{bgcolor:"#dedede",display:"flex",flexDirection:"column",height:"100%",padding:0,width:"20rem"},children:[o.jsxs(rr,{sx:{flexGrow:1},children:[o.jsx(k,{fontWeight:"bold",variant:"h5",color:"textPrimary",textAlign:"center",gutterBottom:!0,children:e}),o.jsx(k,{variant:"h6",fontSize:"1rem",marginBottom:"0.3rem",color:"textPrimary",textAlign:"center",children:"Please do not scroll."}),o.jsx(M,{sx:{minWidth:35},children:o.jsx(k,{variant:"body2",textAlign:"center",color:"text.primary",children:r})})]}),o.jsx(M,{sx:{width:"100%",marginTop:"auto"},children:o.jsx(ur,{numerator:t,denominator:a})})]})}export{fr as P};
