(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/course_history.tsx-BrJAH_ty.js")
    );
  })().catch(console.error);

})();
