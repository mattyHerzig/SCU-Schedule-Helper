(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/course_history.tsx-BUSBwc86.js")
    );
  })().catch(console.error);

})();
