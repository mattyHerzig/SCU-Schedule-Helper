(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/gcal_integration.tsx-BMn8uTym.js")
    );
  })().catch(console.error);

})();
