(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/current_courses.tsx-DG9ciOlj.js")
    );
  })().catch(console.error);

})();
