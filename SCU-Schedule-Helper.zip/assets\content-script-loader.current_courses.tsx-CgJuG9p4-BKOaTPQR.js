(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/current_courses.tsx-CgJuG9p4.js")
    );
  })().catch(console.error);

})();
